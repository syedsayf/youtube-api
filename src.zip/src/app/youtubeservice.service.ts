import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class YoutubeService {
  apiKey: string = 'AIzaSyABKYPgHixaY0oFD2hIUc-K7x_eR0yPxpc'; // Replace with your actual API key
  apiUrl: string = 'https://www.googleapis.com/youtube/v3/search';

  constructor(private http: HttpClient) {}

  searchVideos(query: string): Observable<any> {
    const url = `${this.apiUrl}?q=${query}&part=snippet&type=video&key=${this.apiKey}`;
    return this.http.get(url);
  }

  getPopularVideos(): Observable<any> {
    const maxResults = 20; // Change this value to get more videos
    const url = `${this.apiUrl}?chart=mostPopular&part=snippet&maxResults=${maxResults}&key=${this.apiKey}`;
    return this.http.get(url);
  }
}
