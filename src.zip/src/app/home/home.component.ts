import { Component, OnInit } from '@angular/core';
import { YoutubeService } from '../youtubeservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  recommendedVideos: any[] = [];

  constructor(private youtubeService: YoutubeService) {}

  ngOnInit(): void {
    this.getRecommendedVideos();
  }

  getRecommendedVideos() {
    this.youtubeService.getPopularVideos().subscribe((response: any) => {
      // Update recommendedVideos array with new data
      this.recommendedVideos = response.items;
    });
  }
}
